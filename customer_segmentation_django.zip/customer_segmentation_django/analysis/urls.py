from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.urls import path, include
from analysis.views import signup, login, logout, upload_file, dashboard, about,home



urlpatterns = [
    path('', home, name='home'),
    #path('admin/', admin.site.urls),
    path("signup/",signup, name="signup"),
    path("login/",login, name="login"),
    path("logout/", logout, name="logout"),
    path("upload/", upload_file, name="upload_file"),
    path("dashboard/", dashboard, name="dashboard"),
    path("about/", about, name="about"), 
    

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)