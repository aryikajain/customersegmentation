import pymongo
import gridfs
from gridfs import GridFS
import chardet
import pandas as pd
import bcrypt
from django.conf import settings
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from django.shortcuts import render, redirect
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, DBSCAN
from scipy.cluster.hierarchy import linkage, fcluster
import plotly.express as px
from .forms import UploadFileForm
from .models import UploadedFile

# MongoDB Setup
MONGO_CLIENT = pymongo.MongoClient("mongodb://localhost:27017/")
MONGO_DB = MONGO_CLIENT["customer_segmentation"]
USERS_COLLECTION = MONGO_DB["users"]
CSV_COLLECTION = MONGO_DB["uploaded_csv_data"]
GRID_FS = GridFS(MONGO_DB)
dashboard_data = {}


# Home Page
def home(request):
    return render(request, 'home.html')

# Signup View
def signup(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        hashed_pw = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())

        if USERS_COLLECTION.find_one({"$or": [{"username": username}, {"email": email}]}):
            messages.error(request, "Username or Email already exists!")
            return redirect("signup")

        USERS_COLLECTION.insert_one({
            "username": username,
            "email": email,
            "password": hashed_pw
        })
        messages.success(request, "Account created! You can now log in.")
        return redirect("login")

    return render(request, "signup.html")

# Login View
def login(request):
    if request.method == "POST":
        username_or_email = request.POST["username_or_email"]
        password = request.POST["password"]

        user = USERS_COLLECTION.find_one({
            "$or": [{"username": username_or_email}, {"email": username_or_email}]
        })

        if user and bcrypt.checkpw(password.encode("utf-8"), user["password"]):
            request.session["user_id"] = str(user["_id"])
            messages.success(request, "Login successful!")
            return redirect("upload_file")
        else:
            messages.error(request, "Invalid username, email, or password!")

    return render(request, "login.html")

# Logout View
def logout(request):
    request.session.flush()
    messages.success(request, "Logged out successfully!")
    return redirect("login")

# Upload File View
def upload_file(request):
    if "user_id" not in request.session:
        return redirect("login")

    global dashboard_data

    if request.method == 'POST':
        form = UploadFileForm(request.POST, request.FILES)
        if form.is_valid():
            uploaded_file = request.FILES['file']
            fs = FileSystemStorage()
            filename = fs.save(uploaded_file.name, uploaded_file)
            filepath = fs.path(filename)

            try:
                # Detect encoding
                with open(filepath, 'rb') as f:
                    raw_data = f.read(100000)
                    result = chardet.detect(raw_data)
                encoding = result.get('encoding', 'ISO-8859-1')

                # Try reading CSV
                encodings_to_try = [encoding, 'ISO-8859-1', 'utf-8-sig', 'latin1']
                for enc in encodings_to_try:
                    try:
                        df = pd.read_csv(filepath, encoding=enc, low_memory=False)
                        break
                    except UnicodeDecodeError:
                        continue
                else:
                    return render(request, 'upload.html', {'form': form, 'error': 'Failed to read CSV with common encodings.'})

                # Save file to MongoDB GridFS
                with open(filepath, 'rb') as f:
                    file_id = GRID_FS.put(f, filename=uploaded_file.name, content_type=uploaded_file.content_type)

                UploadedFile.objects.create(file=filename)

                # Save data to MongoDB
                user_id = request.session.get("user_id")
                CSV_COLLECTION.delete_many({"uploaded_by": user_id})
                csv_records = df.to_dict(orient='records')
                for record in csv_records:
                    record['uploaded_by'] = user_id
                if csv_records:
                    CSV_COLLECTION.insert_many(csv_records)

                # Rename columns and clean
                df.rename(columns={'Customer ID': 'CustomerID', 'Invoice': 'InvoiceNo', 'Price': 'UnitPrice'}, inplace=True)
                required_columns = ['CustomerID', 'InvoiceDate', 'InvoiceNo', 'Quantity', 'UnitPrice']
                missing_columns = [col for col in required_columns if col not in df.columns]
                if missing_columns:
                    return render(request, 'upload.html', {'form': form, 'error': f'Missing columns: {", ".join(missing_columns)}'})

                df.dropna(inplace=True)
                df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], errors='coerce')
                df.dropna(subset=['InvoiceDate'], inplace=True)
                df['Total'] = df['Quantity'] * df['UnitPrice']

                # RFM calculation
                snapshot_date = df['InvoiceDate'].max() + pd.Timedelta(days=1)
                rfm = df.groupby('CustomerID').agg({
                    'InvoiceDate': lambda x: (snapshot_date - x.max()).days,
                    'InvoiceNo': 'count',
                    'Total': 'sum'
                }).reset_index().rename(columns={
                    'InvoiceDate': 'Recency',
                    'InvoiceNo': 'Frequency',
                    'Total': 'Monetary'
                })

                # Clustering
                scaler = StandardScaler()
                rfm_scaled = scaler.fit_transform(rfm[['Recency', 'Frequency', 'Monetary']])

                kmeans = KMeans(n_clusters=3, random_state=42, n_init='auto')
                rfm['Cluster_KMeans'] = kmeans.fit_predict(rfm_scaled)

                linked = linkage(rfm_scaled, method='ward')
                rfm['Cluster_Hierarchical'] = fcluster(linked, 3, criterion='maxclust')

                dbscan = DBSCAN(eps=0.5, min_samples=5)
                rfm['Cluster_DBSCAN'] = dbscan.fit_predict(rfm_scaled)

                # Map to customer types
                customer_mapping = {
                    (0, 3, 0): 'Loyal Customers (VIP)',
                    (1, 2, 0): 'Potential Loyalists',
                    (0, 2, 0): 'High-Value Customers',
                    (1, 2, -1): 'Occasional Buyers',
                    (0, 3, -1): 'Churn Risk Customers',
                    (2, 1, -1): 'One-Time Buyers',
                    (2, 3, -1): 'Lost Customers'
                }

                rfm['Customer Type'] = rfm.apply(
                    lambda row: customer_mapping.get((row['Cluster_KMeans'], row['Cluster_Hierarchical'], row['Cluster_DBSCAN']), 'Other'),
                    axis=1
                )

                # Pie chart
                pie_chart = px.pie(
                    rfm,
                    names='Customer Type',
                    title='Customer Distribution by Type',
                    color_discrete_sequence=px.colors.qualitative.Pastel
                ).to_html(full_html=False)

                # Generate downloadable files
                download_links = []
                excel_output_path = fs.path('cluster_comparison_report.xlsx')
                with pd.ExcelWriter(excel_output_path) as writer:
                    rfm.to_excel(writer, sheet_name='RFM & Clusters', index=False)
                download_links.append({'name': 'Cluster Report (Excel)', 'url': '/media/cluster_comparison_report.xlsx'})

                for customer_type in rfm['Customer Type'].unique():
                    subset = rfm[rfm['Customer Type'] == customer_type]
                    output_csv_name = f'{customer_type.replace(" ", "_")}.csv'
                    output_csv_path = fs.path(output_csv_name)
                    subset.to_csv(output_csv_path, index=False)
                    download_links.append({'name': output_csv_name, 'url': f'/media/{output_csv_name}'})

                dashboard_data = {
                    'pie_chart': pie_chart,
                    'download_links': download_links
                }

                return redirect("dashboard")

            except Exception as e:
                return render(request, 'upload.html', {'form': form, 'error': f'Error processing file: {e}'})
        else:
            return render(request, 'upload.html', {'form': form, 'error': 'Invalid form submission'})

    return render(request, 'upload.html', {'form': UploadFileForm()})

def dashboard(request):
    if "user_id" not in request.session:
        return redirect("login")

    return render(request, "dashboard.html", dashboard_data)
 
def about(request):
    return render(request, 'about.html')

